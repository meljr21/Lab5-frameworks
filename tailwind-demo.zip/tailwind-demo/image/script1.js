const hero = document.querySelector('.hero');
console.log(hero); //check if the element is being selected.
const images = ['images/image1.jpg', 'images/image2.jpg', 'images/image3.jpg']; // Replace with your image paths
let currentImageIndex = 0;

function changeBackgroundImage() {
    console.log(images[currentImageIndex]); //check the image path
    hero.style.backgroundImage = `url('${images[currentImageIndex]}')`;
    currentImageIndex = (currentImageIndex + 1) % images.length;
    console.log(currentImageIndex); // check the index.
}

setInterval(changeBackgroundImage, 3000); // Change image every 3 seconds